# Corruptor playable prototype

This folder is an isolated human-vs-bot vertical slice. It does not replace
`CorruptorMain.tscn`, alter the project main scene, or modify any canonical
simulation script.

## Run

Open `Prototype/PlayablePrototype.tscn` in Godot and press **F6**.

Choose both Lords and an integer seed, then:

1. select an order;
2. choose its target and any cards to commit;
3. seal the order;
4. reveal both players' orders;
5. resolve the round;
6. continue until one of the three canonical victory conditions fires.

From round two onward, the log identifies the Reflex Bid winner before
Commitment. Resolution then reports the actual Reflex second action separately
from the two primary revealed orders, including its actor and committed cards.

Most Development is automated by the existing bot doctrines for this first
slice, but its resolved public activity is now reported in the match log:
Market exchanges, castle repairs and their payments, Dominion Rites, Guard
deployments, Summons, and Reflex Bid results. Opponent draws remain private.
Summon is an explicit human decision whenever the player's Lord is banished:
select payment cards, resummon, or remain banished for the round. Commitment,
staged Reveal, and the three clocks are the main human-facing milestone.

Hunt and Siege targeting expose only the defense information the attacker is
allowed to know. Each castle option shows its current breach-adjusted
structural DEF, while the target readout separates structural/Lord defense,
revealed Guard value, face-down Guard count, and the active zone Sigil. Before
a zone has been attacked, its Guard identities and values remain private to
their owner and the readout gives only a known defense floor. An attack turns
the current Guards in that zone face-up; the board and match log then identify
them. Newly deployed Guards begin face-down even when older Guards in that zone
have already been revealed. Sigil creation, aging, expiration, breaks, and
successful blocks are reported explicitly in the match log.

Each player panel now includes a scrollable **Lord Card**. It states the
implemented summon/defense values, explains every active and Breach ability,
and displays live per-Lord state such as Kroni Hunger, Odradek Reconfiguration
tokens, Kanifous's invoked suit, Gremory's once-per-round uses, and Humbaba's
Patient state. When those powers resolve, the match log names the power and
reports its concrete result. These descriptions are based on the canonical
Godot engine behavior used by this prototype; they are not aspirational rules
text.

## Isolation boundary

The prototype calls the existing canonical engines but does not edit them.
Deleting `Prototype/` removes the feature completely and leaves the current
main scene, golden tests, parity runners, and balance lab unchanged.

The same hidden-information boundary applies to both seats. The player sees
their own Guards but sees opposing Guards only after an attack reveals them.
Bot Commitment, Reflex, and Deploy-reservation doctrine receives a private
state view in which the opponent's unrevealed Guard count is preserved but
each hidden value is replaced by the neutral deck expectation (3). The bot
therefore estimates face-down defense instead of reading the real cards.

The controller still generates a normal bot decision for both seats and
replaces seat zero's sealed Commitment with the human choice. This preserves
the existing deterministic flow while allowing the player to own the central
decision.
