class_name PlayableRoundController
extends RefCounted


const SeededGameSetupData = preload(
	"res://Scripts/Sim/SeededGameSetup.gd"
)

const RoundEngineData = preload(
	"res://Scripts/Sim/RoundEngine.gd"
)

const DevelopmentStartEngineData = preload(
	"res://Scripts/Sim/DevelopmentStartEngine.gd"
)

const DominionRiteEngineData = preload(
	"res://Scripts/Sim/DominionRiteEngine.gd"
)

const DeployEngineData = preload(
	"res://Scripts/Sim/DeployEngine.gd"
)

const SummonEngineData = preload(
	"res://Scripts/Sim/SummonEngine.gd"
)

const ReflexBidEngineData = preload(
	"res://Scripts/Sim/ReflexBidEngine.gd"
)

const CommitmentEngineData = preload(
	"res://Scripts/Sim/CommitmentEngine.gd"
)

const RevealEngineData = preload(
	"res://Scripts/Sim/RevealEngine.gd"
)

const ResolutionEngineData = preload(
	"res://Scripts/Sim/ResolutionEngine.gd"
)

const BotRoundEngineData = preload(
	"res://Scripts/Sim/BotRoundEngine.gd"
)

const BotDoctrineData = preload(
	"res://Scripts/Sim/BotDoctrine.gd"
)

const BotPolicyData = preload(
	"res://Scripts/Sim/BotPolicy.gd"
)

const BotDevelopmentDoctrineData = preload(
	"res://Scripts/Sim/BotDevelopmentDoctrine.gd"
)

const BotDominionRiteDoctrineData = preload(
	"res://Scripts/Sim/BotDominionRiteDoctrine.gd"
)

const BotDeployDoctrineData = preload(
	"res://Scripts/Sim/BotDeployDoctrine.gd"
)

const BotResolutionDoctrineData = preload(
	"res://Scripts/Sim/BotResolutionDoctrine.gd"
)

const BotReflexDoctrineData = preload(
	"res://Scripts/Sim/BotReflexDoctrine.gd"
)

const CardData = preload(
	"res://Scripts/Sim/Card.gd"
)


enum Stage {
	NO_GAME,
	SUMMON,
	COMMITMENT,
	SEALED,
	REVEALED,
	TERMINAL,
	INVALID,
}


const HUMAN_PLAYER_ID: int = 0
const BOT_PLAYER_ID: int = 1
const UNKNOWN_GUARD_EXPECTED_VALUE: int = 3


var game = null
var rules: RuleConfig = null
var random_source = null
var policy = null

var stage: Stage = Stage.NO_GAME
var phase_results: Dictionary = {}
var events: Array[Dictionary] = []
var summon_choices: Dictionary = {}
var commitment_choices: Dictionary = {}
var revealed_guard_ids: Dictionary = {}
var guard_reveal_events: Array[Dictionary] = []

var last_result: Dictionary = {}


func start_match(
	human_lord: String,
	bot_lord: String,
	seed_value: int
) -> Dictionary:
	rules = RuleConfig.de_v2()
	policy = BotPolicyData.standard()

	var setup: Dictionary = (
		SeededGameSetupData.setup_locked_game(
			human_lord,
			bot_lord,
			seed_value,
			rules
		)
	)

	game = setup.get(
		"game",
		null
	)

	random_source = setup.get(
		"rng",
		null
	)

	assert(
		game != null,
		"Playable prototype setup did not return a GameState."
	)

	assert(
		random_source != null,
		"Playable prototype setup did not return an RNG."
	)

	stage = Stage.NO_GAME
	phase_results.clear()
	events.clear()
	summon_choices.clear()
	commitment_choices.clear()
	revealed_guard_ids.clear()
	guard_reveal_events.clear()
	last_result.clear()

	return advance_to_commitment()


func advance_to_commitment() -> Dictionary:
	if game == null:
		return _invalid(
			"pre_round",
			"game_not_started"
		)

	if int(
		game.winner
	) >= 0:
		stage = Stage.TERMINAL
		last_result = _round_result(
			true,
			"pre_round"
		)
		return last_result

	var round_number: int = int(
		game.round
	) + 1

	phase_results = {}
	events = []
	summon_choices = {}
	commitment_choices = {}

	RoundEngineData.begin_round(
		game,
		round_number
	)

	_record_phase(
		"begin_round",
		{
			"round": round_number,
		}
	)

	var sigil_result: Dictionary = (
		BotRoundEngineData._update_sigils(
			game,
			rules
		)
	)

	_record_phase(
		"sigil_update",
		sigil_result
	)

	var veil_result: Dictionary = (
		BotRoundEngineData._apply_veil_drift(
			game,
			rules
		)
	)

	_record_phase(
		"veil_drift",
		veil_result
	)

	if int(
		game.winner
	) >= 0:
		stage = Stage.TERMINAL
		last_result = _round_result(
			false,
			"veil_drift"
		)
		return last_result

	var development_start_result: Dictionary = (
		DevelopmentStartEngineData.resolve(
			game,
			rules,
			random_source
		)
	)

	_record_phase(
		"development_start",
		development_start_result
	)

	var draw_result: Dictionary = (
		BotRoundEngineData._resolve_normal_draws(
			game,
			rules,
			random_source
		)
	)

	_record_phase(
		"draw",
		draw_result
	)

	var market_choices: Dictionary = (
		BotDoctrineData.market_choices(
			game,
			random_source
		)
	)

	var market_results: Array[Dictionary] = (
		RoundEngineData.resolve_market(
			game,
			market_choices
		)
	)

	_record_phase(
		"market",
		{
			"choices": market_choices,
			"results": market_results,
		}
	)

	if _contains_invalid(
		market_results
	):
		return _invalid(
			"market",
			"automated_market_invalid"
		)

	var repair_choices: Dictionary = (
		BotDevelopmentDoctrineData.repair_choices(
			game,
			rules,
			random_source,
			policy
		)
	)

	var repair_results: Array[Dictionary] = (
		RoundEngineData.resolve_repairs(
			game,
			rules,
			repair_choices
		)
	)

	_record_phase(
		"repair",
		{
			"choices": repair_choices,
			"results": repair_results,
		}
	)

	if _contains_invalid(
		repair_results
	):
		return _invalid(
			"repair",
			"automated_repair_invalid"
		)

	var rite_choices: Dictionary = (
		BotDominionRiteDoctrineData.rite_choices(
			game,
			rules,
			random_source,
			policy
		)
	)

	var rite_results: Array[Dictionary] = (
		DominionRiteEngineData.resolve(
			game,
			rules,
			rite_choices
		)
	)

	_record_phase(
		"dominion_rites",
		{
			"choices": rite_choices,
			"results": rite_results,
		}
	)

	if _contains_invalid(
		rite_results
	):
		return _invalid(
			"dominion_rites",
			"automated_dominion_rite_invalid"
		)

	if int(
		game.winner
	) >= 0:
		stage = Stage.TERMINAL
		last_result = _round_result(
			false,
			"dominion_rites"
		)
		return last_result

	var deploy_choices: Dictionary = (
		_private_deploy_choices()
	)

	var deploy_results: Array[Dictionary] = (
		DeployEngineData.resolve(
			game,
			rules,
			deploy_choices
		)
	)

	_record_phase(
		"deploy",
		{
			"choices": deploy_choices,
			"results": deploy_results,
		}
	)

	if _contains_invalid(
		deploy_results
	):
		return _invalid(
			"deploy",
			"automated_deploy_invalid"
		)

	summon_choices = (
		BotDevelopmentDoctrineData.summon_choices(
			game,
			rules,
			random_source,
			policy
		)
	)

	var human = get_human_player()

	if human != null and not human.alive:
		stage = Stage.SUMMON
		last_result = {
			"action": "await_summon",
			"reason": "",
			"round": int(
				game.round
			),
			"completed": false,
			"terminal": false,
			"stopped_phase": "summon",
			"winner": -1,
			"win_by": "",
			"phases": phase_results,
			"events": events,
		}
		return last_result

	return _resolve_summon_and_prepare_commitment(
		summon_choices
	)


func resolve_human_summon(
	payment_ids: Array[String],
	pass_summon: bool = false
) -> Dictionary:
	if stage != Stage.SUMMON:
		return _invalid(
			"summon",
			"not_awaiting_summon"
		)

	var human = get_human_player()

	if human == null:
		return _invalid(
			"summon",
			"human_player_missing"
		)

	var human_decision: Dictionary = {
		"pass": true,
	}

	if not pass_summon:
		var validation: Dictionary = (
			SummonEngineData._select_hand_payment(
				human,
				payment_ids,
				human_summon_cost()
			)
		)

		if not bool(
			validation.get(
				"valid",
				false
			)
		):
			return {
				"action": "invalid",
				"reason": String(
					validation.get(
						"reason",
						"invalid_summon_payment"
					)
				),
				"round": int(
					game.round
				),
				"completed": false,
				"terminal": false,
				"stopped_phase": "summon",
				"winner": -1,
				"win_by": "",
				"phases": phase_results,
				"events": events,
			}

		human_decision = {
			"lord": human_summon_lord(),
			"payment": payment_ids.duplicate(),
		}

	summon_choices[HUMAN_PLAYER_ID] = human_decision

	return _resolve_summon_and_prepare_commitment(
		summon_choices
	)


func human_summon_lord() -> String:
	var human = get_human_player()

	if human == null:
		return ""

	if not String(
		human.lord
	).is_empty():
		return String(
			human.lord
		)

	if not human.lord_pool.is_empty():
		return String(
			human.lord_pool[0]
		)

	return ""


func human_summon_cost() -> int:
	var human = get_human_player()

	if human == null:
		return 0

	return BotDevelopmentDoctrineData.summon_cost(
		game,
		human,
		rules,
		human_summon_lord()
	)


func _resolve_summon_and_prepare_commitment(
	decisions: Dictionary
) -> Dictionary:
	var summon_results: Array[Dictionary] = (
		SummonEngineData.resolve(
			game,
			rules,
			decisions
		)
	)

	_record_phase(
		"summon",
		{
			"choices": decisions,
			"results": summon_results,
		}
	)

	if _contains_invalid(
		summon_results
	):
		return _invalid(
			"summon",
			"invalid_summon"
		)

	if int(
		game.winner
	) >= 0:
		stage = Stage.TERMINAL
		last_result = _round_result(
			false,
			"summon"
		)
		return last_result

	var bid_choices: Dictionary = {}

	if int(
		game.round
	) > 1:
		bid_choices = BotDoctrineData.bid_choices(
			game,
			random_source,
			rules,
			policy
		)

	var bid_result: Dictionary = (
		ReflexBidEngineData.resolve(
			game,
			rules,
			bid_choices
		)
	)

	_record_phase(
		"reflex_bid",
		{
			"choices": bid_choices,
			"result": bid_result,
		}
	)

	if String(
		bid_result.get(
			"action",
			""
		)
	) == "invalid":
		return _invalid(
			"reflex_bid",
			String(
				bid_result.get(
					"reason",
					"automated_reflex_bid_invalid"
				)
			)
		)

	# Generate both bot orders so RNG consumption remains stable. Seat zero's
	# order is replaced only after the human seals an explicit choice.
	commitment_choices = (
		BotDoctrineData.commitment_choices(
			_information_view(
				game,
				BOT_PLAYER_ID
			),
			random_source,
			rules,
			policy
		)
	)

	stage = Stage.COMMITMENT
	last_result = {
		"action": "await_commitment",
		"reason": "",
		"round": int(
			game.round
		),
		"completed": false,
		"terminal": false,
		"stopped_phase": "commitment",
		"winner": -1,
		"win_by": "",
		"phases": phase_results,
		"events": events,
	}

	return last_result


func seal_human_commitment(
	human_decision: Dictionary
) -> Dictionary:
	if stage != Stage.COMMITMENT:
		return _invalid(
			"commitment",
			"not_awaiting_commitment"
		)

	commitment_choices[HUMAN_PLAYER_ID] = (
		human_decision.duplicate(
			true
		)
	)

	var commitment_result: Dictionary = (
		CommitmentEngineData.resolve(
			game,
			commitment_choices
		)
	)

	if String(
		commitment_result.get(
			"action",
			""
		)
	) == "invalid":
		# Commitment validates both sealed orders before changing the game.
		return {
			"action": "invalid",
			"reason": String(
				commitment_result.get(
					"reason",
					"invalid_commitment"
				)
			),
			"round": int(
				game.round
			),
			"completed": false,
			"terminal": false,
			"stopped_phase": "commitment",
			"winner": -1,
			"win_by": "",
			"phases": phase_results,
			"events": events,
		}

	_record_phase(
		"commitment",
		{
			"choices": commitment_choices,
			"result": commitment_result,
		}
	)

	stage = Stage.SEALED
	last_result = {
		"action": "sealed",
		"reason": "",
		"round": int(
			game.round
		),
		"completed": false,
		"terminal": false,
		"stopped_phase": "reveal",
		"winner": -1,
		"win_by": "",
		"phases": phase_results,
		"events": events,
	}

	return last_result


func reveal_orders() -> Dictionary:
	if stage != Stage.SEALED:
		return _invalid(
			"reveal",
			"orders_not_sealed"
		)

	var reveal_result: Dictionary = (
		RevealEngineData.resolve(
			game,
			rules,
			random_source
		)
	)

	if String(
		reveal_result.get(
			"action",
			""
		)
	) == "invalid":
		return _invalid(
			"reveal",
			String(
				reveal_result.get(
					"reason",
					"invalid_reveal"
				)
			)
		)

	_record_phase(
		"reveal",
		reveal_result
	)

	stage = Stage.REVEALED
	last_result = {
		"action": "revealed",
		"reason": "",
		"round": int(
			game.round
		),
		"completed": false,
		"terminal": false,
		"stopped_phase": "resolution",
		"winner": -1,
		"win_by": "",
		"phases": phase_results,
		"events": events,
	}

	return last_result


func resolve_revealed_round() -> Dictionary:
	if stage != Stage.REVEALED:
		return _invalid(
			"resolution",
			"orders_not_revealed"
		)

	_reveal_primary_attack_guards()

	var resolution_choices: Dictionary = (
		BotResolutionDoctrineData.build_decisions(
			_information_view(
				game,
				BOT_PLAYER_ID
			),
			rules,
			commitment_choices,
			random_source,
			policy
		)
	)

	resolution_choices["reflex_provider"] = Callable(
		self,
		"_private_reflex_provider"
	)

	var resolution_result: Dictionary = (
		ResolutionEngineData.resolve(
			game,
			rules,
			resolution_choices,
			random_source
		)
	)

	if String(
		resolution_result.get(
			"action",
			""
		)
	) == "invalid":
		return _invalid(
			"resolution",
			String(
				resolution_result.get(
					"reason",
					"invalid_resolution"
				)
			)
		)

	_record_phase(
		"resolution",
		{
			"choices": resolution_choices,
			"result": resolution_result,
		}
	)

	if int(
		game.winner
	) >= 0:
		stage = Stage.TERMINAL
	else:
		stage = Stage.NO_GAME

	last_result = _round_result(
		true,
		(
			"resolution"
			if stage == Stage.TERMINAL
			else ""
		)
	)

	return last_result


func get_human_player():
	if game == null:
		return null

	return game.get_player(
		HUMAN_PLAYER_ID
	)


func get_bot_player():
	if game == null:
		return null

	return game.get_player(
		BOT_PLAYER_ID
	)


func get_bot_commitment() -> Dictionary:
	var raw = commitment_choices.get(
		BOT_PLAYER_ID,
		{}
	)

	if typeof(
		raw
	) != TYPE_DICTIONARY:
		return {}

	return raw


func is_guard_revealed(
	card
) -> bool:
	if card == null:
		return false

	return bool(
		revealed_guard_ids.get(
			int(
				card.get_instance_id()
			),
			false
		)
	)


func consume_guard_reveal_events() -> Array[Dictionary]:
	var result: Array[Dictionary] = (
		guard_reveal_events.duplicate(
			true
		)
	)

	guard_reveal_events.clear()

	return result


func _private_deploy_choices() -> Dictionary:
	var human_choices: Dictionary = (
		BotDeployDoctrineData.deploy_choices(
			_information_view(
				game,
				HUMAN_PLAYER_ID
			),
			rules
		)
	)
	var bot_choices: Dictionary = (
		BotDeployDoctrineData.deploy_choices(
			_information_view(
				game,
				BOT_PLAYER_ID
			),
			rules
		)
	)

	return {
		HUMAN_PLAYER_ID: human_choices.get(
			HUMAN_PLAYER_ID,
			{
				"pass": true,
			}
		),
		BOT_PLAYER_ID: bot_choices.get(
			BOT_PLAYER_ID,
			{
				"pass": true,
			}
		),
	}


func _information_view(
	source_game,
	viewer_id: int
):
	var view = source_game.duplicate_state()

	for metadata_name in source_game.get_meta_list():
		view.set_meta(
			metadata_name,
			source_game.get_meta(
				metadata_name
			)
		)

	var source_opponent = source_game.get_opponent(
		viewer_id
	)
	var view_opponent = view.get_opponent(
		viewer_id
	)

	if (
		source_opponent == null
		or view_opponent == null
	):
		return view

	_mask_guard_array(
		source_opponent.lord_guards,
		view_opponent.lord_guards
	)
	_mask_guard_array(
		source_opponent.castle_guards,
		view_opponent.castle_guards
	)

	view.refresh_derived_values()

	return view


func _mask_guard_array(
	source_guards: Array,
	view_guards: Array
) -> void:
	for index: int in range(
		min(
			source_guards.size(),
			view_guards.size()
		)
	):
		if is_guard_revealed(
			source_guards[index]
		):
			continue

		# Guard count is public. Identity and value are not, so doctrine
		# receives the neutral deck expectation instead of the real card.
		view_guards[index] = CardData.new(
			"Wright",
			UNKNOWN_GUARD_EXPECTED_VALUE
		)


func _reveal_primary_attack_guards() -> void:
	for attacker in game.players:
		var action_name: String = String(
			attacker.action
		)

		if action_name not in [
			"Hunt",
			"Siege",
		]:
			continue

		var defender = game.get_player(
			int(
				attacker.tgt_pid
			)
		)

		if defender == null:
			defender = game.get_opponent(
				int(
					attacker.pid
				)
			)

		_reveal_guard_zone(
			int(
				attacker.pid
			),
			defender,
			(
				"Lord"
				if action_name == "Hunt"
				else "Castle"
			),
			"committed"
		)


func _private_reflex_provider(
	current_game,
	current_rules: RuleConfig
) -> Dictionary:
	var winner_id: int = int(
		current_game.reflex_winner
	)
	var random_state_before = null

	if (
		random_source != null
		and random_source.has_method(
			"duplicate_state"
		)
	):
		random_state_before = (
			random_source.duplicate_state()
		)

	var winner_view = _information_view(
		current_game,
		winner_id
	)
	var bundle: Dictionary = (
		BotReflexDoctrineData.build_decisions(
			winner_view,
			current_rules,
			random_source,
			policy
		)
	)
	var actor_id: int = winner_id
	var action_decision = bundle.get(
		"winner_decision",
		{}
	)
	var breach_decision = bundle.get(
		"breach_decision",
		{}
	)
	var breach_owner_id: int = int(
		current_game.breach_owner
	)

	if (
		current_game.breach == "Odradek"
		and breach_owner_id >= 0
		and breach_owner_id != winner_id
	):
		var breach_bundle: Dictionary = (
			BotReflexDoctrineData.build_decisions(
				_information_view(
					current_game,
					breach_owner_id
				),
				current_rules,
				random_state_before,
				policy
			)
		)

		breach_decision = breach_bundle.get(
			"breach_decision",
			{}
		)
		bundle["breach_decision"] = breach_decision

	if (
		typeof(
			breach_decision
		) == TYPE_DICTIONARY
		and not breach_decision.is_empty()
		and String(
			breach_decision.get(
				"guess",
				""
			)
		) == String(
			action_decision.get(
				"action",
				"Pass"
			)
		)
	):
		actor_id = breach_owner_id
		action_decision = breach_decision.get(
			"stolen_action",
			{}
		)

	if typeof(
		action_decision
	) == TYPE_DICTIONARY:
		_reveal_reflex_attack_guards(
			current_game,
			actor_id,
			action_decision
		)

	return bundle


func _reveal_reflex_attack_guards(
	current_game,
	actor_id: int,
	action_decision: Dictionary
) -> void:
	var action_name: String = String(
		action_decision.get(
			"action",
			"Pass"
		)
	)

	if action_name not in [
		"Hunt",
		"Siege",
	]:
		return

	_reveal_guard_zone(
		actor_id,
		current_game.get_opponent(
			actor_id
		),
		(
			"Lord"
			if action_name == "Hunt"
			else "Castle"
		),
		"reflex"
	)


func _reveal_guard_zone(
	attacker_id: int,
	defender,
	zone: String,
	source: String
) -> void:
	if defender == null:
		return

	var guards: Array = (
		defender.lord_guards
		if zone == "Lord"
		else defender.castle_guards
	)
	var newly_revealed: Array[String] = []

	for card in guards:
		var instance_id: int = int(
			card.get_instance_id()
		)

		if bool(
			revealed_guard_ids.get(
				instance_id,
				false
			)
		):
			continue

		revealed_guard_ids[instance_id] = true
		newly_revealed.append(
			String(
				card.card_id()
			)
		)

	if newly_revealed.is_empty():
		return

	guard_reveal_events.append({
		"attacker_id": attacker_id,
		"defender_id": int(
			defender.pid
		),
		"zone": zone,
		"source": source,
		"cards": newly_revealed,
	})


func _record_phase(
	phase_name: String,
	data
) -> void:
	phase_results[phase_name] = data

	events.append({
		"round": int(
			game.round
		),
		"phase": phase_name,
		"data": data,
	})


func _round_result(
	completed: bool,
	stopped_phase: String
) -> Dictionary:
	return {
		"action": "round",
		"reason": "",
		"round": int(
			game.round
		),
		"completed": completed,
		"terminal": (
			int(
				game.winner
			) >= 0
		),
		"stopped_phase": stopped_phase,
		"winner": int(
			game.winner
		),
		"win_by": String(
			game.win_by
		),
		"phases": phase_results,
		"events": events,
	}


func _invalid(
	phase_name: String,
	reason: String
) -> Dictionary:
	stage = Stage.INVALID

	last_result = {
		"action": "invalid",
		"reason": reason,
		"round": (
			int(
				game.round
			)
			if game != null
			else 0
		),
		"completed": false,
		"terminal": (
			game != null
			and int(
				game.winner
			) >= 0
		),
		"stopped_phase": phase_name,
		"winner": (
			int(
				game.winner
			)
			if game != null
			else -1
		),
		"win_by": (
			String(
				game.win_by
			)
			if game != null
			else ""
		),
		"phases": phase_results,
		"events": events,
	}

	return last_result


func _contains_invalid(
	value
) -> bool:
	if typeof(
		value
	) == TYPE_DICTIONARY:
		var dictionary: Dictionary = value

		if String(
			dictionary.get(
				"action",
				""
			)
		) == "invalid":
			return true

		for nested_value in dictionary.values():
			if _contains_invalid(
				nested_value
			):
				return true

		return false

	if typeof(
		value
	) == TYPE_ARRAY:
		var array: Array = value

		for nested_value in array:
			if _contains_invalid(
				nested_value
			):
				return true

	return false
